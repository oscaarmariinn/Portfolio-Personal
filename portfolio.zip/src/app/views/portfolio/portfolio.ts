import { Component } from '@angular/core';
import { Article } from "../../components/article/article";
import { List } from '../../components/list/list';

@Component({
  selector: 'app-portfolio',
  imports: [Article, List],
  templateUrl: './portfolio.html',
  styleUrl: './portfolio.css',
})
export class Portfolio {

}
