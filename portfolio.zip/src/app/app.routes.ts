import { Routes } from '@angular/router';
import { Projects } from './views/projects/projects';
import { AboutMe } from './views/about-me/about-me';
import { Contact } from './views/contact/contact';
import { Portfolio } from './views/portfolio/portfolio';

export const routes: Routes = [
    { path: '', redirectTo: 'portfolio', pathMatch: 'full' },
    { path: 'portfolio', component: Portfolio },
    { path: 'proyectos', component: Projects },
    { path: 'sobreMi', component: AboutMe },
    { path: 'contacto', component: Contact }
];
